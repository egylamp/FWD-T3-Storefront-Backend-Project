CREATE TABLE products(
    id SERIAL PRIMARY  KEY,
    product_name VARCHAR(255),
    product_price integer,
    product_category VARCHAR(100)
);